"""Create a fully vector, independently animatable implant scene and five stills."""
from pathlib import Path
import random
P=Path(__file__).resolve().parents[1]/'assets'/'implant'; P.mkdir(exist_ok=True)
random.seed(17)
def jaw_teeth():
 out=[]
 for x,y,s,r in [(93,342,.78,-14),(168,359,.87,-11),(252,384,.98,-7),(335,419,1.08,-4),(633,432,1.15,4),(764,399,.98,9),(854,391,.78,14)]:
  out.append(f'<use href="#molar" width="150" height="185" transform="translate({x} {y}) rotate({r}) scale({s})"/>')
 return '\n'.join(out)
def pores():
 p=[]
 for _ in range(360):
  x=random.uniform(356,644); y=random.uniform(593,873); r=random.uniform(1.1,8.0)
  p.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{r:.1f}" ry="{r*random.uniform(.6,1.3):.1f}" fill="{random.choice(["#bb9a70","#d7bd93","#f4e8d4"])}" opacity="{random.uniform(.20,.66):.2f}"/>')
 return '\n'.join(p)
def threads():
 out=[]
 for i in range(15):
  y=48+i*16.3; narrow=max(.42,1-(i-9)*.055)
  w=42*narrow
  out.append(f'<path d="M{-w:.1f} {y:.1f} Q -5 {y+17:.1f} {w:.1f} {y+2:.1f} L {w+2:.1f} {y+11:.1f} Q 3 {y+26:.1f} {-w+1:.1f} {y+9:.1f}Z" fill="url(#goldThread)" stroke="#8d712e" stroke-width="1.3"/><path d="M{-w+3:.1f} {y+2:.1f} Q 0 {y+18:.1f} {w-2:.1f} {y+3:.1f}" fill="none" stroke="#fffbea" stroke-opacity=".85" stroke-width="2.5"/>')
 return '\n'.join(out)
svg='''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1000 1000" role="img" aria-label="تصویرسازی برداری ایمپلنت سپید؛ تاج مرواریدی، رابط طلایی، پیچ تیتانیومی و برش فک">
<defs>
 <radialGradient id="backGlow"><stop stop-color="#fffefa" stop-opacity=".91"/><stop offset=".48" stop-color="#d5eaf8" stop-opacity=".57"/><stop offset="1" stop-color="#d7eaf7" stop-opacity="0"/></radialGradient>
 <radialGradient id="floorShadow"><stop stop-color="#37688b" stop-opacity=".28"/><stop offset="1" stop-color="#37688b" stop-opacity="0"/></radialGradient>
 <linearGradient id="enamel" x1=".07" x2=".95" y1=".07" y2=".93" objectBoundingBox="true"><stop stop-color="#fffefd"/><stop offset=".18" stop-color="#faf7f1"/><stop offset=".43" stop-color="#ffffff"/><stop offset=".69" stop-color="#e3e5e2"/><stop offset=".85" stop-color="#fffdfa"/><stop offset="1" stop-color="#c8d8de"/></linearGradient>
 <linearGradient id="pearl" x1="0" x2="1"><stop stop-color="#c7dce5"/><stop offset=".19" stop-color="#fff"/><stop offset=".46" stop-color="#fffefa"/><stop offset=".78" stop-color="#e4e9ea"/><stop offset="1" stop-color="#b8cbd1"/></linearGradient>
 <linearGradient id="gum" x1=".08" x2=".88" y1="0" y2="1"><stop stop-color="#eaf9ff"/><stop offset=".19" stop-color="#a9d4e6"/><stop offset=".49" stop-color="#c3e1ec"/><stop offset=".8" stop-color="#9fc6d7"/><stop offset="1" stop-color="#638fa7"/></linearGradient>
 <linearGradient id="gumLip" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#f4ffff"/><stop offset=".18" stop-color="#d5f1f7"/><stop offset=".52" stop-color="#8bbace"/><stop offset="1" stop-color="#b4dce8"/></linearGradient>
 <linearGradient id="bone" x1="0" x2="1" y1="0" y2=".8"><stop stop-color="#fff9ec"/><stop offset=".3" stop-color="#ecddc1"/><stop offset=".59" stop-color="#fdf2dd"/><stop offset="1" stop-color="#d5bea0"/></linearGradient>
 <linearGradient id="titanium" x1="0" x2="1"><stop stop-color="#6b7377"/><stop offset=".08" stop-color="#e2e6e4"/><stop offset=".24" stop-color="#919b9c"/><stop offset=".43" stop-color="#fffefd"/><stop offset=".57" stop-color="#a3adaf"/><stop offset=".73" stop-color="#f8f9f4"/><stop offset=".88" stop-color="#858f92"/><stop offset="1" stop-color="#5c6466"/></linearGradient>
 <linearGradient id="gold" x1="0" x2="1"><stop stop-color="#86602a"/><stop offset=".14" stop-color="#d1a95b"/><stop offset=".34" stop-color="#fff0b5"/><stop offset=".55" stop-color="#bb8b3e"/><stop offset=".78" stop-color="#f7d78a"/><stop offset="1" stop-color="#8d672b"/></linearGradient>
 <linearGradient id="goldThread" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#f6f3e8"/><stop offset=".31" stop-color="#9ca3a2"/><stop offset=".56" stop-color="#fffdf4"/><stop offset=".8" stop-color="#c9a24d"/><stop offset="1" stop-color="#775e32"/></linearGradient>
 <radialGradient id="socket"><stop stop-color="#897253"/><stop offset=".7" stop-color="#c6aa80"/><stop offset="1" stop-color="#f9e9c9"/></radialGradient>
 <clipPath id="boneClip"><path d="M390 589 C416 606 434 601 451 583 Q500 602 546 583 C577 600 591 598 613 578 C636 616 655 765 613 850 Q504 899 378 851 C340 777 357 650 390 589Z"/></clipPath>
 <filter id="softBlur" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="19"/></filter>
 <symbol id="molar" viewBox="0 0 150 185"><path d="M13 54 C7 27 25 4 52 18 Q71 -4 88 15 Q111 1 129 19 C149 38 143 69 138 92 Q135 157 112 173 Q80 184 43 171 C19 148 8 99 13 54Z" fill="url(#pearl)" stroke="#b7cbd3" stroke-width="2"/><path d="M18 65 C28 28 46 30 60 45 C68 31 83 28 95 46 C116 30 130 43 138 67" fill="none" stroke="#fff" stroke-opacity=".95" stroke-width="8"/><path d="M42 23 Q56 45 73 36 Q91 27 103 42 M67 39 Q61 57 78 65 Q97 63 104 48" fill="none" stroke="#cbd7d6" stroke-opacity=".65" stroke-width="3"/><path d="M28 82 C33 125 43 149 58 157" fill="none" stroke="#fff" stroke-opacity=".78" stroke-width="8" stroke-linecap="round"/><path d="M126 82 Q128 129 111 151" fill="none" stroke="#b1c4ca" stroke-opacity=".45" stroke-width="7"/></symbol>
</defs>
<ellipse cx="500" cy="430" rx="380" ry="410" fill="url(#backGlow)"/>
<ellipse id="ground-shadow" cx="500" cy="864" rx="195" ry="34" fill="url(#floorShadow)"/>
<g id="jaw-scene" opacity="0" transform="translate(0 76) scale(1 .94)">
 <path d="M76 480 C101 410 190 400 289 444 C352 470 382 511 411 560 Q500 590 587 553 C642 470 777 412 890 455 Q941 474 939 591 L908 737 Q884 810 780 851 C639 904 413 911 221 852 C129 824 89 754 77 666 Q57 563 76 480Z" fill="url(#gum)" stroke="#80aabc" stroke-width="4"/>
 <path d="M104 562 C162 641 261 676 362 663 M640 656 Q785 665 899 559" fill="none" stroke="#fff" stroke-opacity=".22" stroke-width="16"/>
 <g id="neighbor-teeth">__TEETH__</g>
 <path d="M82 543 Q162 496 216 544 Q278 506 346 553 Q393 536 420 590 Q457 607 500 585 Q539 607 582 590 Q629 524 679 551 Q750 514 813 547 Q893 508 933 551 L929 637 Q802 622 743 622 Q640 625 583 645 Q499 616 417 645 Q309 621 238 625 Q129 623 77 650Z" fill="url(#gumLip)" opacity=".85" stroke="#efffff" stroke-opacity=".57" stroke-width="3"/>
 <path d="M390 589 C416 606 434 601 451 583 Q500 602 546 583 C577 600 591 598 613 578 C636 616 655 765 613 850 Q504 899 378 851 C340 777 357 650 390 589Z" fill="url(#bone)" stroke="#e2ceb0" stroke-width="5"/>
 <g clip-path="url(#boneClip)">__PORES__</g>
 <path d="M383 648 C376 747 383 815 404 849 M614 641 Q628 767 599 844" fill="none" stroke="#fff9e9" opacity=".65" stroke-width="9"/>
 <ellipse cx="500" cy="593" rx="60" ry="18" fill="url(#socket)" stroke="#f9e5ba" stroke-width="4"/><ellipse cx="500" cy="593" rx="35" ry="9" fill="#9a805d" opacity=".73"/>
 <path d="M103 586 C186 660 272 710 356 695 M630 699 Q798 723 909 597" fill="none" stroke="#e9faff" opacity=".28" stroke-width="12"/>
</g>
<g id="implant-screw" transform="translate(500 470)">
 <path d="M-42 23 L42 23 L37 247 Q32 288 9 307 Q1 315 -9 307 Q-32 288 -37 247Z" fill="url(#titanium)" stroke="#59666d" stroke-width="2"/>
 <path d="M-26 37 Q-22 184 -10 284" fill="none" stroke="#fff" stroke-opacity=".27" stroke-width="10"/>
 <path d="M29 40 Q25 180 13 286" fill="none" stroke="#465156" stroke-opacity=".21" stroke-width="6"/>
 __THREADS__
 <path d="M-42 22 Q0 29 42 22 L40 38 Q0 51 -40 38Z" fill="url(#titanium)" stroke="#748085" stroke-width="2"/>
 <ellipse cx="0" cy="21" rx="42" ry="13" fill="url(#titanium)" stroke="#9ca5a4" stroke-width="2"/><ellipse cx="0" cy="20" rx="25" ry="7" fill="#71665b" stroke="url(#gold)" stroke-width="3"/><ellipse cx="0" cy="17" rx="18" ry="3.5" fill="#433e39"/>
</g>
<g id="socket-rim" opacity="0"><path d="M436 591 Q465 607 500 608 Q535 607 564 591" fill="none" stroke="#e2f5fa" stroke-width="7" stroke-linecap="round"/><path d="M438 596 Q467 612 500 612 Q533 612 562 596" fill="none" stroke="#82b5c9" stroke-opacity=".7" stroke-width="3"/></g>
<g id="implant-abutment" transform="translate(500 330)">
 <path d="M-30 10 Q0 -3 30 10 L48 95 Q53 112 62 123 L57 143 Q0 154 -57 143 L-62 123 Q-51 109 -48 95Z" fill="url(#titanium)" stroke="#7b898a" stroke-width="2.5"/>
 <path d="M-49 107 Q0 123 49 107 L57 126 Q0 142 -57 126Z" fill="url(#gold)" stroke="#a77b37" stroke-width="2"/><path d="M-56 129 Q0 143 56 129 L55 147 Q0 159 -55 147Z" fill="url(#gold)" stroke="#917036" stroke-width="2"/>
 <path d="M-22 17 L-36 99" stroke="#fff" stroke-width="8" opacity=".65"/><path d="M20 19 L40 99" stroke="#667279" stroke-width="7" opacity=".32"/>
 <ellipse cx="0" cy="11" rx="31" ry="10" fill="url(#titanium)" stroke="#929e9f" stroke-width="2"/><ellipse cx="0" cy="10" rx="19" ry="5.5" fill="#7e705c" stroke="#e8cf92" stroke-width="2"/>
</g>
<g id="implant-crown" transform="translate(500 190)">
 <path d="M-110 70 C-117 33 -98 15 -68 24 Q-47 -4 -17 16 Q9 -10 37 18 Q73 -1 95 24 C124 18 120 54 111 83 C112 143 95 201 58 229 Q23 243 -30 235 Q-86 222 -106 164 Q-120 112 -110 70Z" fill="url(#enamel)" stroke="#b7cbd0" stroke-width="2.6"/>
 <path d="M-100 64 Q-94 33 -73 37 Q-54 37 -43 61 Q-36 24 -14 32 Q0 32 7 62 Q26 21 48 34 Q64 38 63 64 Q88 32 105 58" fill="none" stroke="#fff" stroke-opacity=".91" stroke-width="12" stroke-linecap="round"/>
 <path d="M-67 25 Q-52 43 -45 69 Q-18 55 1 74 Q27 54 48 68 Q64 35 93 39 M-44 69 Q-18 93 2 74 Q18 91 47 69" fill="none" stroke="#bfc9c7" stroke-width="3" stroke-opacity=".55"/>
 <path d="M-87 82 Q-94 137 -63 195" fill="none" stroke="#fff" stroke-width="15" stroke-linecap="round" opacity=".64"/><path d="M75 76 Q98 125 70 197" fill="none" stroke="#aabec6" stroke-opacity=".33" stroke-width="13" stroke-linecap="round"/>
 <path d="M-46 215 Q5 230 55 210" fill="none" stroke="#fff" stroke-opacity=".58" stroke-width="7" stroke-linecap="round"/>
</g>
<g id="tooth-glint" opacity="0"><path d="M467 346 Q474 384 493 395" fill="none" stroke="#fff" stroke-opacity=".8" stroke-width="9" stroke-linecap="round"/><circle cx="469" cy="345" r="6" fill="#fff"/></g>
</svg>'''
svg=svg.replace('__TEETH__',jaw_teeth()).replace('__PORES__',pores()).replace('__THREADS__',threads())
# Keep the hand-built vector illustration as a separate reference asset; the live story uses the image-faithful SVG wrapper in implant-scene.svg.
(P/'implant-scene-vector.svg').write_text(svg,encoding='utf-8')
# Preserve vector-only still states when animation is disabled.
states=[(190,330,470,0,76,0),(80,390,610,0,76,0),(-270,-250,275,1,0,1),(-270,-250,560,1,0,1),(335,460,560,1,0,1)]
for n,(cy,ay,sy,j,dy,rim) in enumerate(states,1):
 image=svg.replace('id="implant-crown" transform="translate(500 190)"',f'id="implant-crown" transform="translate(500 {cy})"'+(' opacity="0"' if n in (3,4) else ''))
 image=image.replace('id="implant-abutment" transform="translate(500 330)"',f'id="implant-abutment" transform="translate(500 {ay})"'+(' opacity="0"' if n in (3,4) else ''))
 image=image.replace('id="implant-screw" transform="translate(500 470)"',f'id="implant-screw" transform="translate(500 {sy})"')
 image=image.replace('id="jaw-scene" opacity="0" transform="translate(0 76) scale(1 .94)"',f'id="jaw-scene" opacity="{j}" transform="translate(0 {dy}) scale(1 1)"')
 image=image.replace('id="socket-rim" opacity="0"',f'id="socket-rim" opacity="{rim}"')
 (P/f'implant-step-{n:02}.svg').write_text(image,encoding='utf-8')
print('Built SVG master and five vector stills')
