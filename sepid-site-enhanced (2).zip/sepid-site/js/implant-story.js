/*
 * Sepid implant story — continuously scrubbed, scroll-pinned and progressively enhanced.
 * All geometry, images and fonts are local; the static four-card version remains the fallback.
 */
const section = document.querySelector('#implant-story');

if (section) {
  const $ = selector => section.querySelector(selector);
  const $$ = selector => [...section.querySelectorAll(selector)];
  const NS = 'http://www.w3.org/2000/svg';
  const html = document.documentElement;
  const body = document.body;
  const visual = $('.implant-visual');
  const lightSweep = $('.implant-light-sweep');
  const copies = $$('.implant-copy');
  const dots = $$('.implant-rail [data-step]');
  const counter = $('[data-current]');
  const progressBar = $('[data-story-progress]');
  const progressFill = $('[data-progress-fill]');
  const note = $('[data-story-status]');
  const liveRegion = $('[data-story-live]');
  const skipButton = $('[data-story-skip]');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const shortScreen = matchMedia('(max-height: 520px)');
  const digits = ['۱', '۲', '۳', '۴'];
  const LAST_STAGE = 3;
  const PIXELS_PER_WHEEL_STORY = 480;
  const PIXELS_PER_TOUCH_STORY = 600;
  const SNAP_DELAY = 190;
  const SPRING_OMEGA = 19;
  const SETTLE_EPSILON = .00045;
  const CENTER = 500;
  const assemblyOffsets = [26, -46, -96];
  const eased = value => {
    const t = Math.max(0, Math.min(1, value));
    return t * t * (3 - 2 * t);
  };
  const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, value));
  const makeSvg = (tag, attrs = {}) => {
    const node = document.createElementNS(NS, tag);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
    return node;
  };

  let enabled = false;
  let broken = false;
  let playing = false;
  let hasCompleted = false;
  let targetProgress = 0;
  let currentProgress = 0;
  let springVelocity = 0;
  let lastDirection = 1;
  let activeStage = -1;
  let raf = 0;
  let lastTime = 0;
  let snapTimer = 0;
  let touch = null;
  let scene = null;
  let frames = [];
  let partLayers = [];
  let finalWordmark = null;
  let wipeRect = null;
  let wipeClipId = '';
  let lockSnapshot = null;
  let entryObserver = null;
  let ariaPercent = -1;
  let initialStatus = 'اسکرول را پیوسته بالا یا پایین ببرید.';
  const wordGroups = copies.map(copy => {
    const nodes = [];
    const walker = document.createTreeWalker(copy, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    textNodes.forEach(textNode => {
      if (!textNode.nodeValue || !textNode.nodeValue.trim()) return;
      const fragment = document.createDocumentFragment();
      textNode.nodeValue.split(/(\s+)/).forEach(part => {
        if (!part) return;
        if (/^\s+$/.test(part)) {
          fragment.append(document.createTextNode(part));
        } else {
          const word = document.createElement('span');
          word.className = 'implant-word';
          word.textContent = part;
          fragment.append(word);
          nodes.push(word);
        }
      });
      textNode.replaceWith(fragment);
    });
    return nodes;
  });

  function storyBounds() {
    const rect = section.getBoundingClientRect();
    const top = rect.top + window.scrollY;
    return { top, bottom: top + rect.height, height: rect.height };
  }

  let backgroundScenePausedByStory = false;
  function pauseBackgroundScene() {
    const model = window.sepidTooth;
    if (!model || typeof model.pause !== 'function' || typeof model.getStats !== 'function') return;
    try {
      if (model.getStats()?.paused) return;
      model.pause();
      backgroundScenePausedByStory = true;
    } catch { backgroundScenePausedByStory = false; }
  }
  function resumeBackgroundScene() {
    if (!backgroundScenePausedByStory) return;
    const model = window.sepidTooth;
    try { if (model && typeof model.resume === 'function') model.resume(); }
    catch { /* the story has already released its own page lock */ }
    finally { backgroundScenePausedByStory = false; }
  }

  function acquirePageLock(top) {
    if (lockSnapshot) return;
    const root = document.documentElement;
    lockSnapshot = {
      top,
      scrollBehavior: root.style.scrollBehavior,
      lockTop: body.style.getPropertyValue('--implant-lock-top'),
      lockTopPriority: body.style.getPropertyPriority('--implant-lock-top')
    };

    root.style.scrollBehavior = 'auto';
    window.scrollTo(0, Math.max(0, Math.round(top)));
    body.style.setProperty('--implant-lock-top', `${-Math.max(0, Math.round(top))}px`);
    root.classList.add('implant-scroll-locked');
    body.classList.add('implant-scroll-locked');
    pauseBackgroundScene();
    window.dispatchEvent(new Event('scroll'));
  }

  function releasePageLock(top) {
    if (!lockSnapshot) return;
    const root = document.documentElement;
    const previousBehavior = lockSnapshot.scrollBehavior;
    root.classList.remove('implant-scroll-locked');
    body.classList.remove('implant-scroll-locked');
    if (lockSnapshot.lockTop) body.style.setProperty('--implant-lock-top', lockSnapshot.lockTop, lockSnapshot.lockTopPriority);
    else body.style.removeProperty('--implant-lock-top');
    root.style.scrollBehavior = 'auto';
    window.scrollTo(0, Math.max(0, Math.round(top)));
    root.style.scrollBehavior = previousBehavior;
    lockSnapshot = null;
    resumeBackgroundScene();
    window.dispatchEvent(new Event('scroll'));
    window.dispatchEvent(new Event('resize'));
  }

  function announce(text) {
    if (liveRegion) liveRegion.textContent = text;
    if (note) note.textContent = text;
  }

  function updateControls(progress) {
    const stage = Math.max(0, Math.min(LAST_STAGE, Math.round(clamp(progress) * LAST_STAGE)));
    if (stage !== activeStage) {
      activeStage = stage;
      counter.textContent = digits[stage];
      dots.forEach((dot, index) => {
        if (index === stage) {
          dot.setAttribute('aria-current', 'step');
          dot.tabIndex = 0;
        } else {
          dot.removeAttribute('aria-current');
          dot.tabIndex = -1;
        }
      });
      if (liveRegion) liveRegion.textContent = `مرحلهٔ ${digits[stage]} از ۴`;
      counter.classList.remove('is-changing');
      // A one-time stage change is rare; the layout read restarts the digit's short entrance animation.
      void counter.offsetWidth;
      counter.classList.add('is-changing');
    }

    const percent = Math.round(clamp(progress) * 100);
    if (progressBar && Math.abs(percent - ariaPercent) >= 1) {
      ariaPercent = percent;
      progressBar.setAttribute('aria-valuenow', String(percent));
      progressBar.setAttribute('aria-valuetext', `مرحلهٔ ${digits[stage]} از ۴؛ ${percent} درصد`);
    }
    if (progressFill) progressFill.style.transform = `scaleX(${clamp(progress).toFixed(4)})`;
    section.classList.toggle('is-complete', hasCompleted && !playing);
    if (note) note.setAttribute('aria-hidden', hasCompleted && !playing ? 'true' : 'false');
  }

  function requestFrame() {
    if (!raf && !document.hidden) raf = requestAnimationFrame(tick);
  }

  function snapTarget() {
    if (!playing) return;
    const stagePosition = clamp(targetProgress) * LAST_STAGE;
    const floor = Math.floor(stagePosition);
    const fraction = stagePosition - floor;
    let nearest;
    if (Math.abs(fraction - .5) < .035) nearest = lastDirection >= 0 ? floor + 1 : floor;
    else nearest = Math.round(stagePosition);
    targetProgress = clamp(nearest / LAST_STAGE);
    requestFrame();
  }

  function scheduleSnap() {
    clearTimeout(snapTimer);
    snapTimer = setTimeout(snapTarget, SNAP_DELAY);
  }

  function setTarget(next, direction, snap = true) {
    if (!playing) return;
    targetProgress = clamp(next);
    if (direction) lastDirection = direction;
    else if (targetProgress >= 1 - SETTLE_EPSILON) lastDirection = 1;
    else if (targetProgress <= SETTLE_EPSILON) lastDirection = -1;
    if (snap) scheduleSnap();
    else clearTimeout(snapTimer);
    requestFrame();
  }

  function addScrollDelta(delta, scale) {
    if (!playing || !delta) return;
    const direction = Math.sign(delta);
    setTarget(targetProgress + delta * scale, direction, true);
  }

  function enterPlayback(startProgress = 0, direction = 1) {
    if (!enabled || broken || !scene || playing) return false;
    const { top } = storyBounds();
    currentProgress = targetProgress = clamp(startProgress);
    springVelocity = 0;
    lastDirection = direction || 1;
    playing = true;
    hasCompleted = false;
    section.classList.add('is-playing', 'is-entering');
    section.classList.remove('is-complete');
    acquirePageLock(top);
    paint(currentProgress);
    updateControls(currentProgress);
    if (note) {
      note.textContent = direction < 0 ? 'در حال بازگشت؛ برای خروج به ابتدای روایت برسید.' : initialStatus;
      note.setAttribute('aria-hidden', 'false');
    }
    setTimeout(() => section.classList.remove('is-entering'), 720);
    requestFrame();
    return true;
  }

  function leavePlayback(edge) {
    if (!playing) return;
    clearTimeout(snapTimer);
    playing = false;
    currentProgress = targetProgress = edge === 'end' ? 1 : 0;
    springVelocity = 0;
    section.classList.remove('is-playing', 'is-entering');
    if (edge === 'end') {
      hasCompleted = true;
      announce('داستان کامل شد؛ اسکرول عادی صفحه ادامه دارد.');
    } else {
      hasCompleted = false;
      announce('به ابتدای داستان رسیدید؛ می‌توانید به بالا بازگردید.');
    }
    releasePageLock(lockSnapshot ? lockSnapshot.top : storyBounds().top);
    paint(currentProgress);
    updateControls(currentProgress);
  }

  function springTick(now) {
    raf = 0;
    if (!playing || document.hidden) return;
    const dt = Math.min(.25, Math.max(.001, lastTime ? (now - lastTime) / 1000 : 1 / 60));
    lastTime = now;

    // Closed-form critically damped spring; it remains stable through fast trackpad bursts.
    const displacement = currentProgress - targetProgress;
    const helper = springVelocity + SPRING_OMEGA * displacement;
    const decay = Math.exp(-SPRING_OMEGA * dt);
    currentProgress = targetProgress + (displacement + helper * dt) * decay;
    springVelocity = (springVelocity - SPRING_OMEGA * helper * dt) * decay;
    currentProgress = clamp(currentProgress);

    if (Math.abs(targetProgress - currentProgress) < SETTLE_EPSILON && Math.abs(springVelocity) < .004) {
      currentProgress = targetProgress;
      springVelocity = 0;
    }

    paint(currentProgress);
    updateControls(currentProgress);

    if (currentProgress >= 1 - SETTLE_EPSILON && targetProgress >= 1 - SETTLE_EPSILON && springVelocity >= -.004 && lastDirection > 0) {
      leavePlayback('end');
      lastTime = 0;
      return;
    }
    if (currentProgress <= SETTLE_EPSILON && targetProgress <= SETTLE_EPSILON && springVelocity <= .004 && lastDirection < 0) {
      leavePlayback('start');
      lastTime = 0;
      return;
    }

    if (Math.abs(targetProgress - currentProgress) > SETTLE_EPSILON || Math.abs(springVelocity) > .004) {
      raf = requestAnimationFrame(springTick);
    } else {
      lastTime = 0;
    }
  }

  function tick(now) { springTick(now); }

  function svgTransform(state, scaleDelta = 0, yDelta = 0) {
    const scale = state.scale + scaleDelta;
    const tx = CENTER * (1 - scale) + state.x;
    const ty = CENTER * (1 - scale) + state.y + yDelta;
    return `translate(${tx.toFixed(2)} ${ty.toFixed(2)}) scale(${scale.toFixed(4)})`;
  }

  function setWordReveal(nodes, alpha, revealProgress, index) {
    const count = Math.max(1, nodes.length);
    nodes.forEach((word, wordIndex) => {
      const reveal = index === 0 ? 1 : clamp(revealProgress * (count + 1) - wordIndex);
      word.style.opacity = (alpha * reveal).toFixed(3);
      const lift = (1 - reveal) * 7;
      word.style.transform = `translate3d(0, ${lift.toFixed(1)}px, 0)`;
      word.style.filter = reveal < .55 ? `blur(${((.55 - reveal) * 3).toFixed(2)}px)` : 'none';
    });
  }

  function paint(progress) {
    if (!scene || frames.length !== 4) return;
    const position = clamp(progress) * LAST_STAGE;
    const from = Math.min(LAST_STAGE, Math.floor(position));
    const to = Math.min(LAST_STAGE, from + 1);
    const local = from === to ? 0 : position - from;
    const blend = eased(local);

    frames.forEach((node, index) => {
      let opacity = 0;
      let state = viewStates[index];
      let scaleDelta = 0;
      let yDelta = 0;
      let blur = 0;
      if (from === to && index === from) {
        opacity = 1;
      } else if (index === from) {
        opacity = 1 - blend;
        state = viewStates[from];
        scaleDelta = .014 * blend;
        yDelta = -4 * blend;
        blur = .35 * blend;
      } else if (index === to) {
        opacity = blend;
        state = viewStates[to];
        scaleDelta = -.022 * (1 - blend);
        yDelta = 6 * (1 - blend);
        blur = 1.8 * (1 - blend);
      }
      node.setAttribute('opacity', opacity.toFixed(4));
      node.setAttribute('transform', svgTransform(state, scaleDelta, yDelta));
      node.style.filter = blur > .04 ? `blur(${blur.toFixed(2)}px)` : 'none';
      node.setAttribute('aria-hidden', opacity > .5 ? 'false' : 'true');
      node.removeAttribute('clip-path');
    });

    if (from !== to && wipeRect) {
      wipeRect.setAttribute('x', (1000 * (1 - blend)).toFixed(2));
      wipeRect.setAttribute('width', (1000 * blend).toFixed(2));
      frames[to].setAttribute('clip-path', `url(#${wipeClipId})`);
    }

    partLayers.forEach((part, index) => {
      let presence = 0;
      let offsetY = 0;
      if (position <= 1) {
        const assembled = eased(position);
        presence = assembled;
        offsetY = assemblyOffsets[index] * (1 - assembled);
      } else if (position <= 2) {
        const returning = eased(position - 1);
        presence = 1 - returning;
      }
      part.node.setAttribute('opacity', presence.toFixed(4));
      part.node.setAttribute('transform', `translate(0 ${offsetY.toFixed(2)})`);
      part.node.setAttribute('aria-hidden', presence < .5 ? 'true' : 'false');
      part.node.style.filter = presence > .05 ? `blur(${((1 - presence) * 1.1).toFixed(2)}px)` : 'none';
    });

    if (finalWordmark) {
      const wordIn = eased(clamp((position - 2.32) / .68));
      finalWordmark.setAttribute('opacity', wordIn.toFixed(4));
      finalWordmark.setAttribute('transform', `translate(0 ${(-26 * (1 - wordIn)).toFixed(1)})`);
    }

    copies.forEach((node, index) => {
      let alpha = 0;
      let reveal = 0;
      if (from === to && index === from) {
        alpha = 1;
        reveal = 1;
      } else if (index === from) {
        alpha = 1 - blend;
        reveal = 1;
      } else if (index === to) {
        alpha = blend;
        reveal = blend;
      }
      node.style.opacity = alpha.toFixed(3);
      node.style.transform = `translate3d(0, ${(22 * (1 - alpha)).toFixed(1)}px, 0)`;
      node.setAttribute('aria-hidden', index === Math.round(position) ? 'false' : 'true');
      setWordReveal(wordGroups[index], alpha, reveal, index);
    });

    if (lightSweep) {
      const activeSweep = from !== to ? Math.sin(Math.PI * blend) : 0;
      lightSweep.style.opacity = (activeSweep * .62).toFixed(3);
      lightSweep.style.transform = `translate3d(${(-145 + blend * 290).toFixed(1)}%, 0, 0) rotate(17deg)`;
    }

    if (progressFill) progressFill.style.transform = `scaleX(${clamp(progress).toFixed(4)})`;
  }

  function createPartLayers(root) {
    const defs = root.querySelector('defs');
    if (!defs) throw new Error('Implant scene is missing SVG definitions');
    const explodedImage = frames[1].querySelector('image');
    const href = explodedImage?.getAttribute('href') || explodedImage?.getAttributeNS('http://www.w3.org/1999/xlink', 'href');
    if (!href) throw new Error('Exploded reference image is missing');

    const paths = [
      // Crown, abutment and screw silhouettes, normalized to the 1000 × 1000 scene viewBox.
      'M499 78 C475 78 451 88 433 105 C413 124 405 153 409 186 C413 226 432 271 451 302 C465 324 482 335 500 336 C518 335 536 324 550 302 C570 270 589 226 592 186 C596 153 587 124 567 105 C549 88 525 78 501 78 C500 78 500 78 499 78 Z',
      'M452 349 C432 352 420 363 421 382 L431 432 C434 449 425 462 429 480 C434 504 453 528 477 541 L523 541 C547 528 566 504 571 480 C575 462 566 449 569 432 L579 382 C580 363 568 352 548 349 C519 345 481 345 452 349 Z',
      'M456 555 C442 558 435 570 438 589 L443 625 C433 635 433 647 444 657 L448 690 C438 701 438 713 450 723 L451 763 C440 773 441 786 454 797 L455 839 C449 858 463 880 484 891 Q500 899 516 891 C537 880 551 858 545 839 L546 797 C559 786 560 773 549 763 L550 723 C562 713 562 701 552 690 L556 657 C567 647 567 635 557 625 L562 589 C565 570 558 558 544 555 C521 551 479 551 456 555 Z'
    ];
    const maskId = `${section.id}-exploded-mask`;
    const mask = makeSvg('mask', { id: maskId, maskUnits: 'userSpaceOnUse', maskContentUnits: 'userSpaceOnUse', x: 0, y: 0, width: 1000, height: 1000, 'mask-type': 'luminance' });
    mask.append(makeSvg('rect', { x: 0, y: 0, width: 1000, height: 1000, fill: '#fff' }));
    paths.forEach(d => mask.append(makeSvg('path', { d, fill: '#000' })));
    defs.append(mask);
    frames[1].setAttribute('mask', `url(#${maskId})`);

    const group = makeSvg('g', { class: 'implant-parts-motion', 'aria-hidden': 'true' });
    const layers = [];
    paths.forEach((d, index) => {
      const clipId = `${section.id}-part-clip-${index}`;
      const clip = makeSvg('clipPath', { id: clipId, clipPathUnits: 'userSpaceOnUse' });
      clip.append(makeSvg('path', { d }));
      defs.append(clip);
      const part = makeSvg('g', { class: `implant-part implant-part-${index + 1}`, 'data-implant-part': ['crown', 'abutment', 'screw'][index], 'clip-path': `url(#${clipId})`, opacity: 0 });
      const image = makeSvg('image', { x: 0, y: 0, width: 1000, height: 1000, preserveAspectRatio: 'xMidYMid slice', href });
      part.append(image);
      group.append(part);
      layers.push({ node: part, name: ['crown', 'abutment', 'screw'][index] });
    });
    root.insertBefore(group, root.querySelector('#final-wordmark'));
    return layers;
  }

  function createWipe(root) {
    const defs = root.querySelector('defs');
    wipeClipId = `${section.id}-rtl-wipe`;
    const clip = makeSvg('clipPath', { id: wipeClipId, clipPathUnits: 'userSpaceOnUse' });
    wipeRect = makeSvg('rect', { x: 1000, y: 0, width: 0, height: 1000 });
    clip.append(wipeRect);
    defs.append(clip);
  }

  function beginEntryFromInput(direction, delta) {
    const bounds = storyBounds();
    const y = window.scrollY;
    if (!hasCompleted && direction > 0) {
      const crossingFromAbove = y <= bounds.top && y + Math.max(1, delta) >= bounds.top - 8;
      const alreadyAtStory = y >= bounds.top - 2 && y < bounds.bottom - 2;
      if (crossingFromAbove || alreadyAtStory) {
        if (enterPlayback(0, 1)) addScrollDelta(delta, 1 / PIXELS_PER_WHEEL_STORY);
        return true;
      }
    }
    if (hasCompleted && direction < 0) {
      const crossingFromBelow = y >= bounds.bottom - 2 && y + delta <= bounds.bottom + 2;
      const insideFromBelow = y > bounds.top + 4 && y < bounds.bottom - 2;
      if (crossingFromBelow || insideFromBelow) {
        if (enterPlayback(1, -1)) addScrollDelta(delta, 1 / PIXELS_PER_WHEEL_STORY);
        return true;
      }
    }
    return false;
  }

  function isFormOrDialog(target) {
    return target instanceof Element && !!target.closest('input, textarea, select, [contenteditable="true"], dialog[open]');
  }

  function announceBlockedNavigation() {
    announce('برای رفتن به بخش‌های دیگر، روایت را تا پایان ببینید یا دکمهٔ «رفتن به پایان» را بزنید.');
  }

  function onWheel(event) {
    if (!enabled || broken || event.ctrlKey) return;
    if (isFormOrDialog(event.target)) return;
    const unit = event.deltaMode === 1 ? 20 : event.deltaMode === 2 ? Math.max(1, window.innerHeight) : 1;
    const delta = Math.max(-1500, Math.min(1500, event.deltaY * unit));
    if (!delta) return;
    const direction = Math.sign(delta);

    if (!playing) {
      if (!beginEntryFromInput(direction, delta)) return;
      event.preventDefault();
      return;
    }
    event.preventDefault();
    addScrollDelta(delta, 1 / PIXELS_PER_WHEEL_STORY);
  }

  function scrollKeyDelta(event) {
    if (event.key === 'ArrowDown' || event.key === 'PageDown' || event.code === 'Space' && !event.shiftKey) return 1 / LAST_STAGE;
    if (event.key === 'ArrowUp' || event.key === 'PageUp' || event.code === 'Space' && event.shiftKey) return -1 / LAST_STAGE;
    return 0;
  }

  function onKeydown(event) {
    if (!enabled || broken || event.altKey || event.ctrlKey || event.metaKey || isFormOrDialog(event.target)) return;

    const dot = event.target instanceof Element ? event.target.closest('.implant-rail [data-step]') : null;
    if (dot) {
      let next = Number(dot.dataset.step);
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = Math.min(LAST_STAGE, next + 1);
      else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = Math.max(0, next - 1);
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = LAST_STAGE;
      else return;
      event.preventDefault();
      const destination = dots[next];
      destination?.focus({ preventScroll: true });
      if (!playing && !enterPlayback(0, 1)) return;
      setTarget(next / LAST_STAGE, Math.sign(next / LAST_STAGE - currentProgress), false);
      return;
    }

    const focusedButton = event.target instanceof Element ? event.target.closest('button') : null;
    if (focusedButton && (event.key === ' ' || event.code === 'Space' || event.key === 'Enter')) return;
    const delta = scrollKeyDelta(event);
    const atStart = event.key === 'Home';
    const atEnd = event.key === 'End';
    if (!playing) {
      const bounds = storyBounds();
      const y = window.scrollY;
      const inStory = y >= bounds.top - 2 && y < bounds.bottom - 2;
      if (atEnd && inStory && !hasCompleted && enterPlayback(0, 1)) {
        event.preventDefault();
        setTarget(1, 1, false);
        return;
      }
      if (atStart && inStory && hasCompleted && enterPlayback(1, -1)) {
        event.preventDefault();
        setTarget(0, -1, false);
        return;
      }
      if (!delta || !inStory) return;
      const direction = Math.sign(delta);
      const start = hasCompleted && direction < 0 ? 1 : 0;
      if (!enterPlayback(start, direction)) return;
    }

    if (atEnd) {
      event.preventDefault();
      setTarget(1, 1, false);
      return;
    }
    if (atStart) {
      event.preventDefault();
      setTarget(0, -1, false);
      return;
    }
    if (!delta) return;
    event.preventDefault();
    setTarget(targetProgress + delta, Math.sign(delta), false);
  }

  function onTouchStart(event) {
    if (event.touches.length !== 1) { touch = null; return; }
    touch = { y: event.touches[0].clientY };
  }

  function onTouchMove(event) {
    if (!enabled || broken || !touch || event.touches.length !== 1 || isFormOrDialog(event.target)) return;
    const y = event.touches[0].clientY;
    const delta = touch.y - y;
    touch.y = y;
    if (Math.abs(delta) < .25) return;
    const direction = Math.sign(delta);
    if (!playing) {
      if (!beginEntryFromInput(direction, delta * PIXELS_PER_WHEEL_STORY / PIXELS_PER_TOUCH_STORY)) return;
      event.preventDefault();
      return;
    }
    event.preventDefault();
    addScrollDelta(delta, 1 / PIXELS_PER_TOUCH_STORY);
  }

  function onTouchEnd() { touch = null; }

  function onAnchorClick(event) {
    if (!enabled || broken) return;
    const link = event.target instanceof Element ? event.target.closest('a[href^="#"]') : null;
    if (!link) return;
    const id = decodeURIComponent(link.getAttribute('href').slice(1));
    const target = document.getElementById(id);
    if (!target) return;

    if (playing) {
      event.preventDefault();
      if (target !== section) announceBlockedNavigation();
      return;
    }
    if (target === section) {
      event.preventDefault();
      const start = hasCompleted ? 0 : 0;
      enterPlayback(start, 1);
      return;
    }
  }

  function blockScrollbarDrag(event) {
    if (!playing) return;
    const viewport = document.documentElement.clientWidth;
    const inGutter = event.clientX >= viewport || event.clientX <= window.innerWidth - viewport;
    if (!inGutter) return;
    event.preventDefault();
    event.stopPropagation();
  }

  function enforceRootLock() {
    if (!playing || !lockSnapshot) return;
    // Fixed-body locking removes the root scroller; reset any programmatic or platform scroll attempt.
    if (window.scrollY !== 0 || document.documentElement.scrollTop !== 0) {
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
    }
  }

  function syncMotionMode() {
    const nextEnabled = !reduced.matches && !shortScreen.matches && !broken;
    if (enabled === nextEnabled) return;
    enabled = nextEnabled;
    section.classList.toggle('is-enhanced', enabled);
    if (!enabled && playing) {
      playing = false;
      clearTimeout(snapTimer);
      cancelAnimationFrame(raf);
      raf = 0;
      section.classList.remove('is-playing', 'is-entering');
      releasePageLock(lockSnapshot ? lockSnapshot.top : storyBounds().top);
    }
  }

  function onSkip() {
    if (!enabled || broken) return;
    if (!playing && !enterPlayback(0, 1)) return;
    setTarget(1, 1, false);
    announce('روایت در حال رفتن به نمای پایانی است.');
  }

  function bindControls() {
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        if (!enabled || broken) return;
        if (!playing && !enterPlayback(hasCompleted ? 1 : 0, hasCompleted ? -1 : 1)) return;
        const destination = index / LAST_STAGE;
        setTarget(destination, Math.sign(destination - currentProgress), false);
      });
    });
    skipButton?.addEventListener('click', onSkip);
  }

  function loadReferenceScene() {
    fetch(new URL('../assets/implant/implant-scene.svg', import.meta.url))
      .then(response => {
        if (!response.ok) throw new Error(`SVG stage HTTP ${response.status}`);
        return response.text();
      })
      .then(async text => {
        const parsed = new DOMParser().parseFromString(text, 'image/svg+xml');
        if (parsed.querySelector('parsererror')) throw new Error('SVG parse error');
        const root = parsed.documentElement;
        const images = [...root.querySelectorAll('image')];
        if (!images.length) throw new Error('SVG stage contains no reference images');
        await Promise.all(images.map(image => new Promise((resolve, reject) => {
          const href = image.getAttribute('href') || image.getAttributeNS('http://www.w3.org/1999/xlink', 'href');
          if (!href) return reject(new Error('Reference image has no href'));
          const preload = new Image();
          preload.onload = resolve;
          preload.onerror = () => reject(new Error(`Could not load ${href}`));
          preload.src = new URL(href, document.baseURI).href;
          if (preload.complete && preload.naturalWidth) resolve();
        })));

        scene = document.importNode(root, true);
        scene.classList.add('implant-photo-scene');
        visual.replaceChildren(scene, lightSweep);
        frames = [...scene.querySelectorAll('[data-photo-frame]')];
        finalWordmark = scene.querySelector('#final-wordmark');
        if (frames.length !== 4 || !finalWordmark) throw new Error('Missing SVG story layers');
        createWipe(scene);
        partLayers = createPartLayers(scene);
        scene.setAttribute('aria-hidden', 'true');
        paint(currentProgress);
        updateControls(currentProgress);

        if ('IntersectionObserver' in window) {
          // Visibility is only a hint for styling; the first lock requires a real user scroll, key or explicit control.
          entryObserver = new IntersectionObserver(entries => {
            if (!enabled || !scene) return;
            section.classList.toggle('is-near', entries.some(entry => entry.isIntersecting));
          }, { threshold: .12, rootMargin: '0px 0px -8% 0px' });
          entryObserver.observe(section);
        } else {
          window.addEventListener('scroll', () => {
            if (!enabled || !scene) return;
            const bounds = storyBounds();
            const visible = bounds.top < window.scrollY + innerHeight * .88 && bounds.bottom > window.scrollY + innerHeight * .12;
            section.classList.toggle('is-near', visible);
          }, { passive: true });
        }
      })
      .catch(error => {
        broken = true;
        playing = false;
        if (lockSnapshot) releasePageLock(lockSnapshot.top);
        section.classList.remove('is-playing', 'is-entering');
        syncMotionMode();
        console.error('Implant story unavailable; static cards remain visible.', error);
      });
  }

  function onVisibilityChange() {
    if (document.hidden) {
      cancelAnimationFrame(raf);
      raf = 0;
      lastTime = 0;
    } else if (playing) requestFrame();
  }

  bindControls();
  document.addEventListener('wheel', onWheel, { capture: true, passive: false });
  document.addEventListener('keydown', onKeydown, true);
  document.addEventListener('touchstart', onTouchStart, { capture: true, passive: true });
  document.addEventListener('touchmove', onTouchMove, { capture: true, passive: false });
  document.addEventListener('touchend', onTouchEnd, { capture: true, passive: true });
  document.addEventListener('touchcancel', onTouchEnd, { capture: true, passive: true });
  document.addEventListener('click', onAnchorClick, true);
  document.addEventListener('pointerdown', blockScrollbarDrag, true);
  window.addEventListener('scroll', enforceRootLock, { passive: true });
  window.addEventListener('resize', () => {
    if (playing) {
      const top = lockSnapshot ? lockSnapshot.top : storyBounds().top;
      acquirePageLock(top);
    }
  }, { passive: true });
  document.addEventListener('visibilitychange', onVisibilityChange);
  reduced.addEventListener('change', syncMotionMode);
  shortScreen.addEventListener('change', syncMotionMode);

  const viewStates = [
    { scale: 1.000, x: 0, y: 0 },
    { scale: 1.018, x: -3, y: -2 },
    { scale: 1.000, x: 0, y: 0 },
    { scale: 1.000, x: 0, y: 0 }
  ];

  syncMotionMode();
  loadReferenceScene();
}
