/*
 * Crisp local SVG comet borders for .service cards.
 * Per-card phase/speed, live-radius geometry, off-screen pausing and fine-pointer tilt.
 */
const cards = [...document.querySelectorAll('#services .service')];
if (cards.length) {
  const SVG = 'http://www.w3.org/2000/svg';
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const states = new Map();
  let pointerRaf = 0;

  const svg = (tag, attrs = {}) => {
    const node = document.createElementNS(SVG, tag);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
    return node;
  };

  function addComet(card, index) {
    const phase = (index * 197 + 71) % 1000;
    const duration = 9.2 + index * 1.35;
    card.style.setProperty('--orbit-phase', `${phase}px`);
    card.style.setProperty('--orbit-duration', `${duration}s`);
    card.style.setProperty('--orbit-hover-duration', `${(duration * .52).toFixed(2)}s`);
    card.style.setProperty('--orbit-delay', `${-(index * .43).toFixed(2)}s`);
    card.style.setProperty('--pointer-x', '50%');
    card.style.setProperty('--pointer-y', '50%');
    card.style.setProperty('--tilt-x', '0deg');
    card.style.setProperty('--tilt-y', '0deg');

    const overlay = svg('svg', {
      class: 'service-border',
      'aria-hidden': 'true',
      focusable: 'false',
      preserveAspectRatio: 'none',
      viewBox: '0 0 100 100'
    });
    const defs = svg('defs');
    const gradientId = `service-comet-gradient-${index}`;
    const blurId = `service-comet-blur-${index}`;
    const gradient = svg('linearGradient', {
      id: gradientId, x1: '0%', y1: '0%', x2: '100%', y2: '100%'
    });
    [
      ['0%', '#7ec3ff', '.05'],
      ['22%', '#7ec3ff', '.44'],
      ['46%', '#c9a24d', '.86'],
      ['69%', '#f5c451', '1'],
      ['87%', '#fff3bf', '1'],
      ['100%', '#ffffff', '.78']
    ].forEach(([offset, color, opacity]) => gradient.append(svg('stop', {
      offset, 'stop-color': color, 'stop-opacity': opacity
    })));
    const filter = svg('filter', { id: blurId, x: '-35%', y: '-35%', width: '170%', height: '170%' });
    filter.append(svg('feGaussianBlur', { stdDeviation: '4.2' }));
    defs.append(gradient, filter);
    overlay.append(defs);

    const strokes = [
      { name: 'aura', width: 8, dash: '178 822', color: `url(#${gradientId})`, opacity: .34, phase: phase + 22, filter: `url(#${blurId})` },
      { name: 'sky-tail', width: 1.7, dash: '92 908', color: '#7ec3ff', opacity: .72, phase: phase + 64 },
      { name: 'gold-tail', width: 2, dash: '152 848', color: `url(#${gradientId})`, opacity: .98, phase: phase + 22 },
      { name: 'comet-head', width: 2.35, dash: '34 966', color: '#f5c451', opacity: 1, phase },
      { name: 'white-core', width: 1.15, dash: '8 992', color: '#fffdf3', opacity: 1, phase: phase - 4 }
    ];
    const rects = [];
    strokes.forEach(layer => {
      const rect = svg('rect', {
        x: .7, y: .7, width: 98.6, height: 98.6, rx: 15,
        fill: 'none', pathLength: 1000, stroke: layer.color,
        'stroke-width': layer.width, 'stroke-dasharray': layer.dash,
        'stroke-dashoffset': layer.phase, 'stroke-linecap': 'round',
        opacity: layer.opacity, class: `service-comet service-comet-${layer.name}`
      });
      if (layer.filter) rect.setAttribute('filter', layer.filter);
      rect.style.setProperty('--orbit-offset', String(layer.phase));
      overlay.append(rect);
      rects.push(rect);
    });

    card.append(overlay);
    const state = { card, overlay, rects, bounds: null, measure: true, tx: 0, ty: 0, x: 0, y: 0, active: false, index };
    states.set(card, state);
    return state;
  }

  const allStates = cards.map(addComet);

  function resizeCard(state) {
    const { card, overlay } = state;
    const rect = card.getBoundingClientRect();
    const width = Math.max(1, rect.width);
    const height = Math.max(1, rect.height);
    const radius = parseFloat(getComputedStyle(card).borderTopLeftRadius) || 16;
    overlay.setAttribute('viewBox', `0 0 ${width.toFixed(2)} ${height.toFixed(2)}`);
    state.rects.forEach(path => {
      path.setAttribute('x', '.7');
      path.setAttribute('y', '.7');
      path.setAttribute('width', Math.max(0, width - 1.4).toFixed(2));
      path.setAttribute('height', Math.max(0, height - 1.4).toFixed(2));
      path.setAttribute('rx', Math.max(3, radius - .7).toFixed(2));
    });
    state.bounds = rect;
    state.measure = false;
  }

  const resizeObserver = 'ResizeObserver' in window ? new ResizeObserver(entries => {
    entries.forEach(entry => {
      const state = states.get(entry.target);
      if (state) resizeCard(state);
    });
  }) : null;
  allStates.forEach(state => {
    if (resizeObserver) resizeObserver.observe(state.card);
    else resizeCard(state);
  });

  const visibilityObserver = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => entry.target.classList.toggle('is-visible', entry.isIntersecting));
  }, { rootMargin: '140px 0px', threshold: 0 }) : null;
  if (visibilityObserver) allStates.forEach(state => visibilityObserver.observe(state.card));
  else allStates.forEach(state => state.card.classList.add('is-visible'));

  function requestPointerFrame() {
    if (!pointerRaf && !document.hidden && finePointer.matches && !reducedMotion.matches) {
      pointerRaf = requestAnimationFrame(renderPointer);
    }
  }

  function renderPointer() {
    pointerRaf = 0;
    let active = false;
    allStates.forEach(state => {
      if (!state.active && Math.abs(state.tx - state.x) + Math.abs(state.ty - state.y) < .06) {
        state.x = state.tx;
        state.y = state.ty;
        state.card.style.setProperty('--tilt-x', '0deg');
        state.card.style.setProperty('--tilt-y', '0deg');
        state.card.style.setProperty('--pointer-x', '50%');
        state.card.style.setProperty('--pointer-y', '50%');
        return;
      }
      if (state.measure || !state.bounds) resizeCard(state);
      state.x += (state.tx - state.x) * .24;
      state.y += (state.ty - state.y) * .24;
      if (Math.abs(state.tx - state.x) < .06) state.x = state.tx;
      if (Math.abs(state.ty - state.y) < .06) state.y = state.ty;
      const { width, height } = state.bounds;
      const tiltY = Math.max(-3.1, Math.min(3.1, (state.x / Math.max(1, width)) * 6.2));
      const tiltX = Math.max(-3.1, Math.min(3.1, (state.y / Math.max(1, height)) * -6.2));
      state.card.style.setProperty('--pointer-x', `${(width / 2 + state.x * 2.4).toFixed(1)}px`);
      state.card.style.setProperty('--pointer-y', `${(height / 2 + state.y * 2.4).toFixed(1)}px`);
      state.card.style.setProperty('--tilt-x', `${tiltY.toFixed(2)}deg`);
      state.card.style.setProperty('--tilt-y', `${tiltX.toFixed(2)}deg`);
      active ||= Math.abs(state.tx - state.x) + Math.abs(state.ty - state.y) > .06;
    });
    if (active) pointerRaf = requestAnimationFrame(renderPointer);
  }

  allStates.forEach(state => {
    state.card.addEventListener('pointerenter', event => {
      if (!finePointer.matches || reducedMotion.matches || event.pointerType === 'touch') return;
      state.measure = true;
      resizeCard(state);
      state.active = true;
      state.card.classList.add('is-pointer-active');
    }, { passive: true });
    state.card.addEventListener('pointermove', event => {
      if (!finePointer.matches || reducedMotion.matches || event.pointerType === 'touch') return;
      if (state.measure || !state.bounds) resizeCard(state);
      const rect = state.bounds;
      state.tx = Math.max(-rect.width / 2, Math.min(rect.width / 2, event.clientX - rect.left - rect.width / 2));
      state.ty = Math.max(-rect.height / 2, Math.min(rect.height / 2, event.clientY - rect.top - rect.height / 2));
      state.active = true;
      state.card.classList.add('is-pointer-active');
      requestPointerFrame();
    }, { passive: true });
    const reset = () => {
      state.active = false;
      state.tx = state.ty = 0;
      state.card.classList.remove('is-pointer-active');
      requestPointerFrame();
    };
    state.card.addEventListener('pointerleave', reset, { passive: true });
    state.card.addEventListener('blur', reset, true);
    state.card.addEventListener('focus', () => {
      state.card.classList.add('is-focused');
    }, true);
    state.card.addEventListener('blur', () => state.card.classList.remove('is-focused'), true);
  });

  window.addEventListener('scroll', () => allStates.forEach(state => { state.measure = true; }), { passive: true });
  window.addEventListener('resize', () => allStates.forEach(state => { state.measure = true; }), { passive: true });
  document.addEventListener('visibilitychange', () => {
    document.documentElement.classList.toggle('is-document-hidden', document.hidden);
    if (document.hidden) {
      cancelAnimationFrame(pointerRaf);
      pointerRaf = 0;
    }
  });
  reducedMotion.addEventListener('change', () => {
    if (reducedMotion.matches) {
      cancelAnimationFrame(pointerRaf);
      pointerRaf = 0;
      allStates.forEach(state => {
        state.active = false;
        state.tx = state.ty = state.x = state.y = 0;
        state.card.classList.remove('is-pointer-active');
        state.card.style.setProperty('--tilt-x', '0deg');
        state.card.style.setProperty('--tilt-y', '0deg');
      });
    }
  });
  window.addEventListener('pagehide', event => {
    if (event.persisted) return;
    resizeObserver?.disconnect();
    visibilityObserver?.disconnect();
    cancelAnimationFrame(pointerRaf);
  }, { once: true });
}
